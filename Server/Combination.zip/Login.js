let { Pool } = require("./Database");
const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
require("dotenv").config();
var jwt = require("jsonwebtoken");
let tokenKey = process.env.tokenKey;
let loginData = [
  { Phone: "+251927177475", Pass: "tariku9138" },
  { Phone: "+251922112480", Pass: "marew123" },
];
router.post("/", (req, res) => {
  let { phoneNumber, Password } = req.body;
  let isAvailable = false;
  try {
    loginData.map((Data) => {
      let { Phone, Pass } = Data;
      if (Phone == phoneNumber && Password == Pass) {
        isAvailable = true;
      }
    });
    if (isAvailable) {
      res.json({ Messages: "success" });
    } else {
      res.json({ Messages: "fail" });
    }
  } catch (error) {
    console.log("error", error);
    res.json({ Messages: "error" });
  }
});
router.get("/", async (req, res) => {
  try {
    console.log("req.query", req.query);
    let { formData } = req.query;
    let { phoneNumber, Password, Role } = JSON.parse(formData);
    let selectUser = ``;

    let verifyPasswordRoleAndUserId = async (userId, Password, Role) => {
      let verifyInUsers = `select * from usersTable where userId = '${userId}' and password = '${Password}' and role = '${Role}'`;
      console.log("verifyInUsers", verifyInUsers);
      let [results2Verify] = await Pool.query(verifyInUsers);
      if (results2Verify.length == 0) {
        return res.json({
          Messages: "You are not a user in this password and role ",
        });
      }

      var token = jwt.sign({ userId: userId }, tokenKey);
      console.log("token", token);
      // return;
      res.json({ Messages: "success", Token: token, userId });
    };
    if (Role == "Teacher") {
      selectUser = `select * from teachers where teachersPhoneNumber='${phoneNumber}'`;
      let [responces] = await Pool.query(selectUser);
      if (responces.length == 0) {
        return res.json({
          Messages: "This teacher is not registered in this phone number",
        });
      }
      let { teachersId } = responces[0];
      verifyPasswordRoleAndUserId(teachersId, Password, Role);
    } else if (Role == "Admin") {
      let select = `select * from admin where adminPhone='${phoneNumber}'`;
      let [Responces] = await Pool.query(select);
      console.log("Responces", Responces);
      if (Responces.length == 0) {
        return res.json({
          Messages: "This admin is not registered in this phone",
        });
      }
      let { adminId } = Responces[0];
      verifyPasswordRoleAndUserId(adminId, Password, Role);
    } else if (Role == "Student") {
      let select = `select * from  students where contactNumber='${phoneNumber}'  `;
      let [Results] = await Pool.query(select);
      if (Results.length > 0) {
        console.log("Results", Results);
        let { id } = Results[0];
        verifyPasswordRoleAndUserId(id, Password, Role);
      } else {
        res.json({ Messages: "no student in this phone number" });
      }
    } else if (Role == "Parent") {
      let select = `select * from parent where `;
      let Results = await Pool.query(select);
    }
  } catch (error) {
    console.log("error", error);
    res.json({ Messages: "error" });
  }
});
router.delete("/", (req, res) => {
  res.json({ Messages: "Connected" });
});
router.put("/", (req, res) => {
  res.json({ Messages: "Connected" });
});
module.exports = router;
